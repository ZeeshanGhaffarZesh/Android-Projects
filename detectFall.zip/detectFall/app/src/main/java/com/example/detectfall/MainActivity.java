package com.example.detectfall;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    TextView txtVal;
    Boolean isFall = true;
    MediaPlayer mediaPlayer;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtVal = findViewById(R.id.txtValues);

        SensorManager sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);

        if (sensorManager != null){

            Sensor accelerometerSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

            if(accelerometerSensor != null){
                sensorManager.registerListener(this,accelerometerSensor,SensorManager.SENSOR_DELAY_NORMAL);

            }


        }else {
            Toast.makeText(this, "Sensor Service Not Detected", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {

        if(sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER){
            double vector = Math.sqrt(Math.pow(sensorEvent.values[0],2) * Math.pow(sensorEvent.values[1],2) * Math.pow(sensorEvent.values[2],2) );
            DecimalFormat precision = new DecimalFormat("0.00");
            double ldAccRound = Double.parseDouble(precision.format(vector));

            if(isFall){

                if (ldAccRound > 0.3d && ldAccRound < 0.5d) {
                    isFall = false;
                    Toast.makeText(this, "Fall detected!", Toast.LENGTH_SHORT).show();
                    playSound();


                    Intent intent = new Intent(MainActivity.this,userStatus.class);
                    startActivity(intent);

                }

            }


        }

    }

    private void playSound() {
        if (mediaPlayer == null) { //first time
            mediaPlayer = MediaPlayer.create(getBaseContext(), R.raw.hmscream);
        } else if (mediaPlayer.isPlaying()) { //duh don't start it again.
            //Toast.makeText(getBaseContext(), "I'm playing already", Toast.LENGTH_SHORT).show();
            return;
        } else { //play it at least one, reset and play again.
            mediaPlayer.seekTo(0);
        }
        mediaPlayer.start();


    }

    private void KillMediaPlayer() {
        if (mediaPlayer != null)
            mediaPlayer.release();
    }



    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }


}