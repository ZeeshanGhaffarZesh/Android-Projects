package com.example.detectfall;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class takeCareTaker extends AppCompatActivity {

    Button btnSave;
    EditText etName,etPhoneNumber;


    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_take_care_taker);

        btnSave = findViewById(R.id.btnSave);
        etName = findViewById(R.id.etName);
        etPhoneNumber = findViewById(R.id.etPhoneNumber);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String careTakerName = etName.getText().toString();
                String careTakerPhone = etPhoneNumber.getText().toString();

                sharedPreferences = getSharedPreferences("care_taker_info",MODE_PRIVATE);
                SharedPreferences.Editor myEdit = sharedPreferences.edit();

                myEdit.putString("ctName", careTakerName);
                myEdit.putString("ctPhone",careTakerPhone);

                myEdit.apply();
                Intent intent = new Intent(takeCareTaker.this,MainActivity.class);
                startActivity(intent);
            }
        });



    }
}